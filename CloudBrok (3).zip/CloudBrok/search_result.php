<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    table
    {
    	margin-top: 10px;
    }
    .headerLink
    {
    	cursor: pointer;
    }
    th
    {
    	padding: 5px;
    }

    td
    {
    	padding: 5px;
    }

    </style>

</head>

<body>

    <!-- Navigation -->
    

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header class="business-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline"><img src="images/logo.png"/></h1>
                </div>
            </div>
        </div>
        
    </header>

    <!-- Page Content -->
    <div class="search-result">
    
    </div>
<?php
include("connection.php");

      	$ram = trim($_POST['RAM']);
	    $cpu = trim($_POST['CPU']);
		$storage = trim($_POST['Storage']);
		$encrypted = trim($_POST['Encrypted']);
		$cdn = trim($_POST['CDN']);
  		$query = "SELECT * FROM manage_host WHERE field_values LIKE '%$ram%' AND field_values LIKE '%$cpu%' AND field_values LIKE '%$storage%' AND field_values LIKE '%$encrypted%' AND field_values LIKE '%$cdn%'";
  $result = $con->query($query);
  //print_r($result);

?>
<table cellspacing="0" class="table-striped table-bordered">
<?php
$qry_pro   =  $con->query("select * from manage_host where category is null");
$providers = mysqli_fetch_assoc($qry_pro);
?>
<tr>
<th>
<?php echo $providers['field_name'];?>
</th>
<?php $hosts = unserialize($providers['field_values']);
foreach($hosts as $host)
{
	?>
		<th>
		<?php echo $host;?>
		</th>

	<?php
}
?>
</tr>
<tr>
<th colspan="24">Cloud Features & Management</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Features & Management'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
	$i=0;
    foreach($field_values as $field_value)
	{
		$i++;
		if($i==1){
				
		}
		?>
    	<td><?php echo $field_value;
		if(trim($field_value) == 'English'){
			echo "great";	
		}
		?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Cloud Servers</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Servers'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <?php 
	$hcss = '';
	$hs = array('RAM','Storage','CPU cores');
	if (in_array(trim( $result['field_name']), $hs)) {
			$hcss = 'style="font-weight:bold; background-color:#abc;"';	
		}
	?>
    <td <?php //echo $hcss; ?>><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		$color = '';
		$os = array($ram,$cpu,$storage);
		if (trim($field_value) != '' && in_array(trim($field_value), $os)) {
			$color = 'style="color:#FF0; background-color:#00aa00;"';	
		}
		?>
    	<td <?php echo $color; ?>><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Security</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Security'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Reliability & Failover</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Reliability & Failover'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>
<tr>
<th colspan="24">Services</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Services'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>
</table>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><a href="dashboard.php">Login</a> | Copyright &copy; Cloud Broke 2015</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>