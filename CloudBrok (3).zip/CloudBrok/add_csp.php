<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Add Cloud Service Provider | CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include("header.php");?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Cloud Service Provider</h1>
                        <form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Add CSP</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="name">Service Provider</label>  
  <div class="col-md-6">
  <input id="name" name="name" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- File Button --> 
<div class="form-group">
  <label class="col-md-4 control-label" for="logo">Logo</label>
  <div class="col-md-4">
    <input id="logo" name="logo" class="input-file" type="file">
  </div>
</div>

<!-- Multiple Checkboxes -->
<div class="form-group">
  <label class="col-md-4 control-label" for="pricingplan">Pricing Plan</label>
  <div class="col-md-4">
  <div class="checkbox">
    <label for="pricingplan-0">
      <input type="checkbox" name="pricingplan" id="pricingplan-0" value="Pay as You Go">
      Pay as You Go
    </label>
  </div>
  <div class="checkbox">
    <label for="pricingplan-1">
      <input type="checkbox" name="pricingplan" id="pricingplan-1" value="Year + Discount">
      Year + Discount
    </label>
  </div>
  <div class="checkbox">
    <label for="pricingplan-2">
      <input type="checkbox" name="pricingplan" id="pricingplan-2" value="Monthly">
      Monthly
    </label>
  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="avgPrice">Average Price /  Month</label>  
  <div class="col-md-6">
  <input id="avgPrice" name="avgPrice" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="servicelevel">Service Level Agreement</label>  
  <div class="col-md-6">
  <input id="servicelevel" name="servicelevel" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="datacenter">Data Center</label>  
  <div class="col-md-6">
  <input id="datacenter" name="datacenter" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="certification">Certifications</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="certification-0">
      <input type="radio" name="certification" id="certification-0" value="Yes" checked="checked">
      Yes
    </label> 
    <label class="radio-inline" for="certification-1">
      <input type="radio" name="certification" id="certification-1" value="No">
      No
    </label>
  </div>
</div>

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="scale-up">Scale-up</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="scale-up-0">
      <input type="radio" name="scale-up" id="scale-up-0" value="Yes" checked="checked">
      Yes
    </label> 
    <label class="radio-inline" for="scale-up-1">
      <input type="radio" name="scale-up" id="scale-up-1" value="No">
      No
    </label>
  </div>
</div>

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="scale-out">Scale Out</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="scale-out-0">
      <input type="radio" name="scale-out" id="scale-out-0" value="Yes" checked="checked">
      Yes
    </label> 
    <label class="radio-inline" for="scale-out-1">
      <input type="radio" name="scale-out" id="scale-out-1" value="No">
      No
    </label>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="support">Support</label>
  <div class="col-md-6">
    <select id="support" name="support" class="form-control">
      <option value="Extensive">Extensive</option>
      <option value="Average">Average</option>
      <option value="Poor">Poor</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="monitoring">Monitoring</label>
  <div class="col-md-6">
    <select id="monitoring" name="monitoring" class="form-control">
      <option value="Extensive">Extensive</option>
      <option value="Average">Average</option>
      <option value="Poor">Poor</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="api">API</label>
  <div class="col-md-6">
    <select id="api" name="api" class="form-control">
      <option value="Extensive">Extensive</option>
      <option value="Average">Average</option>
      <option value="Poor">Poor</option>
    </select>
  </div>
</div>

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="freeTier">Free Tier</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="freeTier-0">
      <input type="radio" name="freeTier" id="freeTier-0" value="Yes" checked="checked">
      Yes
    </label> 
    <label class="radio-inline" for="freeTier-1">
      <input type="radio" name="freeTier" id="freeTier-1" value="No">
      No
    </label>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="suppos">Supporting OS</label>  
  <div class="col-md-6">
  <input id="suppos" name="suppos" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="instypes">Instance Types</label>  
  <div class="col-md-6">
  <input id="instypes" name="instypes" type="text" placeholder="" class="form-control input-md">
  <span class="help-block">-1 for Configurable</span>  
  </div>
</div>

<!-- Prepended text-->
<div class="form-group">
  <label class="col-md-4 control-label" for="costout">Cost Out</label>
  <div class="col-md-6">
    <div class="input-group">
      <span class="input-group-addon">$</span>
      <input id="costout" name="costout" class="form-control" placeholder="" type="text">
    </div>
    <p class="help-block">per GB</p>
  </div>
</div>

<!-- Prepended text-->
<div class="form-group">
  <label class="col-md-4 control-label" for="costin">Cost In</label>
  <div class="col-md-6">
    <div class="input-group">
      <span class="input-group-addon">$</span>
      <input id="costin" name="costin" class="form-control" placeholder="" type="text">
    </div>
    <p class="help-block">per GB</p>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Save</button>
  </div>
</div>

</fieldset>
</form>


                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>