<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    table
    {
    	margin-top: 10px;
    }
    .headerLink
    {
    	cursor: pointer;
    }
    th
    {
    	padding: 5px;
    }

    td
    {
    	padding: 5px;
    }

    </style>

</head>

<body>

    <!-- Navigation -->
    

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header class="business-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline"><img src="images/logo.png"/></h1>
                </div>
            </div>
        </div>
        
    </header>

    <!-- Page Content -->
    <div class="container-fluid">

     

        <div class="row">
            <div class="col-sm-12">
                <?php

include("connection.php");

$query = "select * from cloudserviceprovider";
$result = $con->query($query);
?>
<table class="table-striped table-bordered">


<tr><th><a data-target="#myModal" data-toggle="modal" class="headerLink"> Service Provider</a></th><th><a data-target="#myModal1" data-toggle="modal" class="headerLink">Pricing Plan</a></th><th><a data-target="#myModal2" data-toggle="modal" class="headerLink">Average Price/Month</a></th><th><a data-target="#myModal3" data-toggle="modal" class="headerLink">Service Level Agreements</a></th><th><a data-target="#myModal4" data-toggle="modal" class="headerLink">Data Centers</a></th><th><a data-target="#myModal5" data-toggle="modal" class="headerLink">Certifications</a></th><th><a data-target="#myModal6" data-toggle="modal" class="headerLink">Scale Up</a></th><th><a data-target="#myModal7" data-toggle="modal" class="headerLink">Scale Out</a></th><th><a data-target="#myModal8" data-toggle="modal" class="headerLink">Support</a></th><th><a data-target="#myModal9" data-toggle="modal" class="headerLink"> Monitoring</a></th><th><a data-target="#myModal10" data-toggle="modal" class="headerLink">APIs</a></th><th><a data-target="#myModal11" data-toggle="modal" class="headerLink">Free Tier</a></th><th><a data-target="#myModal12" data-toggle="modal" class="headerLink">Operating Systems Supported</a></th><th><a data-target="#myModal13" data-toggle="modal" class="headerLink">Number of Instances</a></th><th><a data-target="#myModal14" data-toggle="modal" class="headerLink">Data Transfer out (/GB)</a></th><th><a data-target="#myModal15" data-toggle="modal" class="headerLink">Data Transfer in (/GB)</a></th></tr>

<?php
while ($row = mysqli_fetch_assoc($result)) 
{
?>
<tr><td><?php echo $row["csp_name"];?></td><td><?php echo $row["csp_pricing_plan"];?></td><td><?php echo $row["csp_amp"];?></td><td><?php echo $row["csp_sla"];?></td><td><?php echo $row["csp_data_centers"];?></td><td><?php echo $row["csp_certifications"];?></td><td><?php echo $row["csp_scale_up"];?></td><td><?php echo $row["csp_scale_out"];?></td><td><?php echo $row["csp_support"];?></td><td><?php echo $row["csp_monitoring"];?></td><td><?php echo $row["csp_api"];?></td><td><?php echo $row["csp_freetier"];?></td><td><?php echo $row["csp_supp_os"];?></td><td><?php echo $row["csp_num_ins"];?></td><td><?php echo $row["csp_out_bound"];?></td><td><?php echo $row["csp_in_bound"];?></td></tr>
<?php
}
?>
</table>
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Service Provider</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Pricing Plan</h4>
      </div>
      <div class="modal-body">
       Providers offer pay-as-you-go (usually hourly) plans, monthly pricing plans, “membership” discounts (where the user receives a discount in usage rates in exchange for an extra yearly payment), or any combination thereof. The more options provided, the better, but the pay-as-you-go model is the most interesting stand-alone option, since it allows for more fine-grained usage control. Only the prominently displayed payment plans were considered.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Average Monthly Price</h4>
      </div>
      <div class="modal-body">
       Estimated cost in US$ for a 1 CPU, 2GB RAM cloud server (or the nearest best option), averaged over datacenters for companies with location-based pricing, and averaged over Windows/Linux servers. When available, hourly pricing was used, based on 730-hour months. Otherwise, monthly pricing was used. Excludes data transfer costs.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Service Level Agreement offered</h4>
      </div>
      <div class="modal-body">
        The uptime SLA offered (regardless of past performance), in percentage points.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Number of Data centers</h4>
      </div>
      <div class="modal-body">
        The number of datacenters offered as a choice when deploying cloud servers.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Certifications</h4>
      </div>
      <div class="modal-body">
        If the vendor has compliance- and security-related certifications, such as PCI or SAS 70.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Scale Up</h4>
      </div>
      <div class="modal-body">
        If it is possible to scale up individual cloud server instances by adding more memory, extra CPUs or more storage space.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal7" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Scale Out</h4>
      </div>
      <div class="modal-body">
        If it is possible to quickly deploy new server instances.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal8" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Support</h4>
      </div>
      <div class="modal-body">
        A three-level subjective scale:
        <ul>
		<li>Poor – Companies that only offer on-line forums for free; any other support must be paid</li>
		<li> Average – Companies that offer a single type of 24x7 support for free (either phone-based or on-line chat), in addition to forums</li>
		<li> Extensive – Companies with multiple support offerings included in the base price</li>
		</ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal9" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Monitoring</h4>
      </div>
      <div class="modal-body">
        Another three-level subjective scale:
        <ul>
		<li> Poor – Companies that have no monitoring/alert solutions integrated, requiring the deployment of third-party tools or that extra services be purchased</li>
		<li> Average – Companies with very simple integrated monitoring tools (few indicators or no alerting)</li>
		<li> Extensive – Companies with very complete integrated monitoring tools offered for no additional cost</li>
		</ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal10" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">APIs</h4>
      </div>
      <div class="modal-body">
        If the company offers APIs to interact with the servers or not.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal11" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Free Tier</h4>
      </div>
      <div class="modal-body">
        If the provider has a “free trial” tier that customers can use to test the service.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal12" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Supporting Operating Systems</h4>
      </div>
      <div class="modal-body">
        The number of supported operating systems, regardless of version, available as a pre-configured image.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal13" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Instance Types</h4>
      </div>
      <div class="modal-body">
        The number of different server configurations available. Some providers offer fully customizable servers in terms of CPU, these are listed as “configurable”.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal14" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Cost of Outbound Data Transfer</h4>
      </div>
      <div class="modal-body">
        The cost, in US$, for each GB of outbound data sent from the server. Companies that offer a per second (Mbps) connection for free have costs listed as zero.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal15" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Cost of Inbound Data Transfer</h4>
      </div>
      <div class="modal-body">
        The cost, in US$, for each GB of inbound data sent from the server. Companies that offer a per second (Mbps) connection for free have costs listed as zero.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

            </div>
           
        </div>
     

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><a href="dashboard.php">Login</a> | Copyright &copy; Cloud Broke 2015</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
