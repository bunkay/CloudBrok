<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    table
    {
    	margin-top: 10px;
    }
    .headerLink
    {
    	cursor: pointer;
    }
    th
    {
    	padding: 5px;
    }

    td
    {
    	padding: 5px;
    }

    </style>

</head>

<body>

    <!-- Navigation -->
    

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header style="background-color: rgb(238, 238, 238); margin-bottom: 15px; padding-bottom: 15px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline"><a href="http://mywebcity.in/cloudbrok/"><img src="images/logo.png"/></a></h1>
                </div>
            </div>
        </div>
        
    </header>

<div class="container">
            <div class="row search-field">
                
    <!-- Page Content -->
    
     <form role="form" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
     <div class="col-lg-3 col-sm-6">
 <div class="form-group"> 
  <label for="sel1">RAM:</label>
  <select class="form-control" name="RAM">
  <option value="">Select</option>
  <?php $ram_arr = array("256 MB - 64 GB","256 MB - 16 GB","2 GB - 120 GB","1 GB - 64 GB","1 GB - 256 GB","256 MB - 256 GB","512 MB - 22 GB");
  	foreach($ram_arr as $ra){
		if(isset($_POST['RAM']) && $_POST['RAM']==$ra){
			echo '<option value="'.$ra.'" selected>'.$ra.'</option>';
		} else {
			echo '<option value="'.$ra.'">'.$ra.'</option>';
		}
	}
   ?>
  
  </select>
</div></div>
<div class="col-lg-3 col-sm-6">
  <div class="form-group">
  <label for="sel1">CPU cores:</label>
  <select class="form-control" name="CPU">
  <option value="1">Select</option>
  <?php $cpu_arr = array("1 - 8","1 - 16","1 - 20","1 - 32","1 - 64","2 - 8");
  	foreach($cpu_arr as $cp){
		if(isset($_POST['CPU']) && $_POST['CPU']==$cp){
			echo '<option value="'.$cp.'" selected>'.$cp.'</option>';
		} else {
			echo '<option value="'.$cp.'">'.$cp.'</option>';
		}
	}
   ?>
  </select>
</div>
</div>
<div class="col-lg-3 col-sm-6">
  <div class="form-group">
  <label for="sel1">Storage:</label>
  <select class="form-control" name="Storage">
  <option value="">Select</option>
   <?php $storage_arr = array("1 GB - 5 TB","1 GB - 500 GB","1 GB - 64 TB","5 GB - 16 TB","10 GB - 650 GB");
  	foreach($storage_arr as $st){
		if(isset($_POST['Storage']) && $_POST['Storage']==$st){
			echo '<option value="'.$st.'" selected>'.$st.'</option>';
		} else {
			echo '<option value="'.$st.'">'.$st.'</option>';
		}
	}
   ?>
  </select>
</div>
</div>
<div class="col-lg-3 col-sm-6">
  <div class="form-group">
  <label for="sel1">Encrypted storage:</label>
  <select class="form-control" name="Encrypted">
  <option value="">Select</option>
  <?php $encrypted_arr = array("yes","no");
  	foreach($encrypted_arr as $en){
		if(isset($_POST['Encrypted']) && $_POST['Encrypted']==$en){
			echo '<option value="'.$en.'" selected>'.ucwords($en).'</option>';
		} else {
			echo '<option value="'.$en.'">'.ucwords($en).'</option>';
		}
	}
   ?>
  </select>
</div>
</div>
<div class="col-lg-3 col-sm-6">
  <div class="form-group">
  <label for="sel1">Backup Storage:</label>
  <select class="form-control" name="Backup">
  <option value="">Select</option>
  <?php $encrypted_arr = array("yes","no");
  	foreach($encrypted_arr as $en){
		if(isset($_POST['Backup']) && $_POST['Backup']==$en){
			echo '<option value="'.$en.'" selected>'.ucwords($en).'</option>';
		} else {
			echo '<option value="'.$en.'">'.ucwords($en).'</option>';
		}
	}
   ?>
  </select>
</div>
</div>
<div class="col-lg-3 col-sm-6">
  <div class="form-group">
  <label for="sel1">CDN service:</label>
  <select class="form-control" name="CDN">
  <option value="">Select</option>
<?php $cdn_arr = array("yes","no");
  	foreach($cdn_arr as $cd){
		if(isset($_POST['CDN']) && $_POST['CDN']==$cd){
			echo '<option value="'.$cd.'" selected>'.ucwords($cd).'</option>';
		} else {
			echo '<option value="'.$cd.'">'.ucwords($cd).'</option>';
		}
	}
   ?>
  </select>
  </div></div>
 <div class="col-lg-3 col-sm-6"><div class="form-group"> <label>&nbsp; </label><input type="submit" name="submit" class="btn btn-danger form-control" value="Search"> </div></div>

 </form>

</div>


<div class="row">

<?php
include("connection.php");
if(isset($_POST['submit'])){
      	$ram = trim($_POST['RAM']);
	    $cpu = trim($_POST['CPU']);
		$storage = trim($_POST['Storage']);
		$encrypted = trim($_POST['Encrypted']);
		$backup = trim($_POST['Backup']);
		$cdn = trim($_POST['CDN']);
  		
  //print_r($result);

?>
<h2>Search Result:-</h2>
<table cellspacing="0" class="table-striped table-bordered">
<tr><td colspan="10">You can also see search result in colored table format. Here all green box will indicate your search keyword.</td></tr>
<?php
$best_providers_name = array();
$qry_pro   =  $con->query("select * from manage_host where category is null");
$providers = mysqli_fetch_assoc($qry_pro);
?>
<tr class="info">
<th>
<?php echo $providers['field_name'];?>
</th>
<?php $hosts = unserialize($providers['field_values']);
foreach($hosts as $host)
{
	?>
		<th>
		<?php echo $host;
		$best_providers_name[] = $host;
		?>
		</th>

	<?php
}
?>
</tr>
<tr>
<th colspan="24">Cloud Features & Management</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Features & Management'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value; ?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Cloud Servers</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Servers'");
$best_providers = array();
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <?php 
	$hcss = '';
	$hs = array('RAM','Storage','CPU cores');
	if (in_array(trim( $result['field_name']), $hs)) {
			$hcss = 'style="font-weight:bold; background-color:#abc;"';	
		}
	?>
    <td <?php //echo $hcss; ?>><?php echo $result['field_name'];?></td>
    <?php
	$i = 0;
    foreach($field_values as $field_value)
	{
		$color = '';
		$os = array($ram,$cpu,$storage);
		if (trim($field_value) != '' && in_array(trim($field_value), $os)) {
			if(isset($best_providers[$i])){
				$best_providers[$i] = $best_providers[$i] + 1;
			} else {
				$best_providers[$i] = 1;
			}
			
			$color = 'style="color:#FF0; background-color:#00aa00;"';	
		}
		$i++;
		?>
    	<td <?php echo $color; ?>><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Security</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Security'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
	$i=0;
    foreach($field_values as $field_value)
	{
		$color = '';
		$os = array($encrypted);
		if (trim($field_value) != '' && in_array(trim($field_value), $os) && trim($result['field_name']) == 'Encrypted storage') {
			if(isset($best_providers[$i])){
				$best_providers[$i] = $best_providers[$i] + 1;
			} else {
				$best_providers[$i] = 1;
			}
			$color = 'style="color:#FF0; background-color:#00aa00;"';	
		}
		$i++;
		?>
    	<td <?php echo $color; ?>><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Reliability & Failover</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Reliability & Failover'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
	$i=0;
    foreach($field_values as $field_value)
	{
		$color = '';
		$os = array($backup);
		if (trim($field_value) != '' && in_array(trim($field_value), $os) && trim($result['field_name']) == 'Backup - storage') {
			if(isset($best_providers[$i])){
				$best_providers[$i] = $best_providers[$i] + 1;
			} else {
				$best_providers[$i] = 1;
			}
			$color = 'style="color:#FF0; background-color:#00aa00;"';	
		}
		$i++;
		?>
    	<td <?php echo $color; ?>><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>
<tr>
<th colspan="24">Services</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Services'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
	$i=0;
    foreach($field_values as $field_value)
	{
		$color = '';
		$os = array($cdn);
		if (trim($field_value) != '' && in_array(trim($field_value), $os) && trim($result['field_name']) == 'CDN service') {
			if(isset($best_providers[$i])){
				$best_providers[$i] = $best_providers[$i] + 1;
			} else {
				$best_providers[$i] = 1;
			}
			$color = 'style="color:#FF0; background-color:#00aa00;"';	
		}
		$i++;
		?>
    	<td <?php echo $color; ?>><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
$j=0;
echo 'We found top 3 Providers for you as per your search criteria. <ol>';
foreach($best_providers as $key=>$val){
	$j++;
		if($j<4){
			echo '<li>'.$best_providers_name[$key].'</li>';	
		} else {
			break;
		}
}
echo '</ul>';
?>
</table>
<?php } ?>
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><a href="dashboard.php">Login</a> | Copyright &copy; Cloud Broke 2015</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
 </div>   <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>