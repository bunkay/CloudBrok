<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    table
    {
    	margin-top: 10px;
    }
    .headerLink
    {
    	cursor: pointer;
    }
    th
    {
    	padding: 5px;
    }

    td
    {
    	padding: 5px;
    }

    </style>

</head>

<body>

    <!-- Navigation -->
    

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header style="background-color: rgb(238, 238, 238); margin-bottom: 15px; padding-bottom: 15px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline"><a href="http://mywebcity.in/cloudbrok/"><img src="images/logo.png"/></a></h1>
                </div>
            </div>
        </div>
        
    </header>
    <!-- Page Content -->
    <div class="container-fluid">

     

        <div class="row">
            <div class="col-sm-12">
<style>
th, td{ border:1px solid;}
</style>
<?php
include("connection.php");
?>
<table cellspacing="0" class="table-striped table-bordered">
<?php
$qry_pro   =  $con->query("select * from manage_host where category is null");
$providers = mysqli_fetch_assoc($qry_pro);
?>
<tr>
<th>
<?php echo $providers['field_name'];?>
</th>
<?php $hosts = unserialize($providers['field_values']);
foreach($hosts as $host)
{
	?>
		<th>
		<?php echo $host;?>
		</th>

	<?php
}
?>
</tr>
<tr>
<th colspan="24">Cloud Features & Management</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Features & Management'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Cloud Servers</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Cloud Servers'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Security</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Security'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>

<tr>
<th colspan="24">Reliability & Failover</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Reliability & Failover'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>
<tr>
<th colspan="24">Services</th>
</tr>
<?php
$qry  =  $con->query("select * from manage_host where category = 'Services'");
while($result = mysqli_fetch_array($qry))
{
	$field_values = unserialize($result['field_values']);
	?>
    <tr>
    <td><?php echo $result['field_name'];?></td>
    <?php
    foreach($field_values as $field_value)
	{
		?>
    	<td><?php echo $field_value;?></td>
        <?php
    }
	?>
    </tr>
    <?php
}
?>
</table>
</div>

            </div>
           
        </div>
     

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><a href="dashboard.php">Login</a> | Copyright &copy; Cloud Broke 2015</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>