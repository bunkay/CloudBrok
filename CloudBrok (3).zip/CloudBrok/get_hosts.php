<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CloudBrok</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    table
    {
    	margin-top: 10px;
    }
    .headerLink
    {
    	cursor: pointer;
    }
    th
    {
    	padding: 5px;
    }

    td
    {
    	padding: 5px;
    }

    </style>

</head>

<body>

    <!-- Navigation -->
    

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header style="background-color: rgb(238, 238, 238); margin-bottom: 15px; padding-bottom: 15px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="tagline"><a href="http://mywebcity.in/cloudbrok/"><img src="images/logo.png"/></a></h1>
                </div>
            </div>
        </div>
        
    </header>

    <!-- Page Content -->
    <div class="container-fluid">

     

        <div class="row">
            <div class="col-sm-12">
<?php
//error_reporting(0);
$servername = "localhost";
$username   = "roomrent_clients";
$password   = "XMAT3EJB";

// Create connection
$conn = new mysqli($servername, $username, $password, "roomrent_cloudbrok");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

include('simple_html_dom.php');
 
mysqli_query($conn, "TRUNCATE manage_host");


$html           = file_get_html('https://www.cloudorado.com/cloud_providers_comparison.jsp');
$tables         = $html->find('table');
$e              = $html->find('tr');
$provider_value = array();
$provider_key   = 'Providers';
$img            = array();


preg_match_all('/<img[^>]+>/i',$e[0], $result); 

foreach( $result[0] as $img_tag )
{
    preg_match_all('/(title)=("[^"]*")/i',$img_tag, $img[$img_tag]);
}

foreach($img as $title)
{
	$title            = str_replace('"','',$title[2][0]);	
	$provider_value[] = $title;
}
$provider_values = serialize($provider_value);

mysqli_query($conn, "insert into manage_host (`field_name`, `field_values`) values ('$provider_key', '$provider_values')");
$i = 0;

foreach($e as $row)
{
	if($i >= 0)
	{		
		if(preg_match("/hide1 featureLabel/i", $row, $match))
		{
			$category         = 'Cloud Features & Management';
			$titles           = array();
		   	preg_match('/<span title="(.*)"> (.*)<\/span>/i', $row, $titles);
			$title_inner      = explode('">',$titles[0]);
			$title_inner_main = explode('</span>',$title_inner[1]);			 
			
		   	$matches = array();
			preg_match('/<div class="cell-content"> (.*)<\/div>/i', $row, $matches);
			$first_step = explode( '<div class="cell-content">' , $matches[0] );
			$field_value = array();
			$j = 0;
			foreach($first_step as $subrow)
			{
				if($j > 0)
				{
					preg_match_all('/(alt)=("[^"]*")/i',$subrow, $alt);
					$altValue = array_filter($alt);
					if (!empty($altValue))
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $alt[2][0]);
						$altValue = preg_replace('/"/i', '' , $altValue);
						$field_value[] = $altValue;
					}
					else
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $subrow);
						$altValue = preg_replace('/<img[^>]+>/i', '' , $altValue);
						$field_value[] = strip_tags($altValue);
					}
				}
				$j++;
			}

			$field_values = serialize($field_value);			
			mysqli_query($conn,"insert into manage_host (`field_name`, `field_values`, `category` ) values ('".$title_inner_main[0]."', '".$field_values."', '".$category."')");
		}
		
		if(preg_match("/hide2 featureLabel/i", $row, $match))
		{
			$category         = 'Cloud Servers';
			$titles           = array();
		   	preg_match('/<span title="(.*)"> (.*)<\/span>/i', $row, $titles);
			$title_inner      = explode('">',$titles[0]);
			$title_inner_main = explode('</span>',$title_inner[1]);			 
			
		   	$matches = array();
			preg_match('/<div class="cell-content"> (.*)<\/div>/i', $row, $matches);
			$first_step = explode( '<div class="cell-content">' , $matches[0] );
			$field_value = array();
			$j=0;
			foreach($first_step as $subrow)
			{
				if($j > 0)
				{
					preg_match_all('/(alt)=("[^"]*")/i',$subrow, $alt);
					$altValue = array_filter($alt);
					if (!empty($altValue))
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $alt[2][0]);
						$altValue = preg_replace('/"/i', '' , $altValue);
						$field_value[] = $altValue;
					}
					else
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $subrow);
						$altValue = preg_replace('/<img[^>]+>/i', '' , $altValue);
						$field_value[] = strip_tags($altValue);
					}
				}
				$j++;
			}
			$field_values = serialize($field_value);
			
			mysqli_query($conn,"insert into manage_host (`field_name`, `field_values`, `category` ) values ('".$title_inner_main[0]."', '".$field_values."', '".$category."')");
		}
		
		if(preg_match("/hide6 featureLabel/i", $row, $match))
		{
			$category = 'Security';
			$titles           = array();
		   	preg_match('/<span title="(.*)"> (.*)<\/span>/i', $row, $titles);
			$title_inner      = explode('">',$titles[0]);
			$title_inner_main = explode('</span>',$title_inner[1]);			 
			
		   	$matches = array();
			preg_match('/<div class="cell-content"> (.*)<\/div>/i', $row, $matches);
			$first_step = explode( '<div class="cell-content">' , $matches[0] );
			$field_value = array();
			$j=0;
			
			foreach($first_step as $subrow)
			{
				if($j > 0)
				{
					preg_match_all('/(alt)=("[^"]*")/i',$subrow, $alt);
					$altValue = array_filter($alt);
					if (!empty($altValue))
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $alt[2][0]);
						$altValue = preg_replace('/"/i', '' , $altValue);
						$field_value[] = $altValue;
					}
					else
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $subrow);
						$altValue = preg_replace('/<img[^>]+>/i', '' , $altValue);
						$field_value[] = strip_tags($altValue);
					}
				}
				$j++;
			}
			$field_values = serialize($field_value);
			
			mysqli_query($conn,"insert into manage_host (`field_name`, `field_values`, `category` ) values ('".$title_inner_main[0]."', '".$field_values."', '".$category."')");
		}
		
		if(preg_match("/hide8 featureLabel/i", $row, $match))
		{
			$category = 'Reliability & Failover';
			$titles           = array();
		   	preg_match('/<span title="(.*)"> (.*)<\/span>/i', $row, $titles);
			$title_inner      = explode('">',$titles[0]);
			$title_inner_main = explode('</span>',$title_inner[1]);			 
			
		   	$matches = array();
			preg_match('/<div class="cell-content"> (.*)<\/div>/i', $row, $matches);
			$first_step = explode( '<div class="cell-content">' , $matches[0] );
			$field_value = array();
			$j=0;
			
			foreach($first_step as $subrow)
			{
				if($j > 0)
				{
					preg_match_all('/(alt)=("[^"]*")/i',$subrow, $alt);
					$altValue = array_filter($alt);
					if (!empty($altValue))
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $alt[2][0]);
						$altValue = preg_replace('/"/i', '' , $altValue);
						$field_value[] = $altValue;
					}
					else
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $subrow);
						$altValue = preg_replace('/<img[^>]+>/i', '' , $altValue);
						$field_value[] = strip_tags($altValue);
					}
				}
				$j++;
			}
			$field_values = serialize($field_value);
			
			mysqli_query($conn,"insert into manage_host (`field_name`, `field_values`, `category` ) values ('".$title_inner_main[0]."', '".$field_values."', '".$category."')");
		}
		
		if(preg_match("/hide9 featureLabel/i", $row, $match))
		{
			$category = 'Services';
			$titles           = array();
		   	preg_match('/<span title="(.*)"> (.*)<\/span>/i', $row, $titles);
			$title_inner      = explode('">',$titles[0]);
			$title_inner_main = explode('</span>',$title_inner[1]);			 
			
		   	$matches = array();
			preg_match('/<div class="cell-content"> (.*)<\/div>/i', $row, $matches);
			$first_step = explode( '<div class="cell-content">' , $matches[0] );
			$field_value = array();
			$j=0;
			
			foreach($first_step as $subrow)
			{
				if($j > 0)
				{
					preg_match_all('/(alt)=("[^"]*")/i',$subrow, $alt);
					$altValue = array_filter($alt);
					if (!empty($altValue))
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $alt[2][0]);
						$altValue = preg_replace('/"/i', '' , $altValue);
						$field_value[] = $altValue;
					}
					else
					{
						$altValue = preg_replace('/<div class="commentContainer">(.*)<\/div>/i', '' , $subrow);
						$altValue = preg_replace('/<img[^>]+>/i', '' , $altValue);
						$field_value[] = strip_tags($altValue);
					}
				}
				$j++;
			}
			$field_values = serialize($field_value);
			
			mysqli_query($conn,"insert into manage_host (`field_name`, `field_values`, `category` ) values ('".$title_inner_main[0]."', '".$field_values."', '".$category."')");
		}
	}
$i++;
}
?>
<center><h1>Database updated successfully!<br><br>
<a href="view_hosts.php" class="btn btn-success">View Result</a></h1></center>
</div>

            </div>
           
        </div>
     

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><a href="dashboard.php">Login</a> | Copyright &copy; Cloud Broke 2015</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>